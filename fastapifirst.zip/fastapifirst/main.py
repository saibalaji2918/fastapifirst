from fastapi import FastAPI, Query, Form, File, UploadFile
from typing import Union
from enum import Enum

from pydantic import BaseModel

app_name = FastAPI()

class Schema1(BaseModel):
    name: str
    Class :str
    roll_no :int

class Choice_names(str, Enum):
    alexnet = "alexnet"
    resnet = "resnet"
    lenet = "lenet"



@app_name.get("/hello")
async def root():
    return {"message": "Hello World"}


@app_name.get("/hi")
async def vizag():
    return {"message": "Hello Vizag"}

@app_name.get("/item/{Item}")
def path_func(Item):
    if Item:
        var_name = {"path value":Item}
        return (var_name)
    else:
        return ("no path variables!")

@app_name.get("/query")
def query_fun(name:Union[str, None]=None, roll_no:Union[str, None]=Query(default=None, min_length=3, max_length=3)):
    var_name = {"name": name, "roll no": roll_no}
    return (var_name)

@app_name.get("/models/{model_name}")
async def get_model(model_name: Choice_names):
    if model_name is Choice_names.alexnet:
        return {"model_name": model_name, "message": "Deep Learning FTW!"}

    if model_name.value == "lenet":
        return {"model_name": model_name, "message": "LeCNN all the images"}

    return {"model_name": model_name, "message": "Have some residuals"}


@app_name.post("/student")
def create_item(item: Schema1):
    return item

class new_student(BaseModel):
    one : str
    two : str
    three : int

#form data
@app_name.post("/form/data")
# async def form_data(username : str = Form(), password : str = Form()):
async def form_data(items : new_student):
    return ({"items": items})
    
@app_name.post("/form/data")
async def form_data(username : str = Form(), password : str = Form()):
    return({"username": username, "password": password})

# FILE UPLOAD
@app_name.post("/file/upload")
async def files_bytes_len(file : bytes = File()):
    return({"files":len(file)})

@app_name.post("/upload/file")
async def file_upload(file : UploadFile):
    return({"file_name":file.filename, "file_content_name":file.content_type})

